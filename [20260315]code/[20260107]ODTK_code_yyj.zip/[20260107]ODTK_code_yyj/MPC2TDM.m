clear all; clc;

function mpc80_to_tdm(input_file, output_file)
    % MPC80格式数据转换为CCSDS TDM格式（符合CCSDS 503.0-B-2标准）
    
    % 读取MPC80数据
    fid = fopen(input_file, 'r');
    lines = textscan(fid, '%s', 'Delimiter', '\n');
    fclose(fid);
    lines = lines{1};
    
    % 收集所有观测数据
    observations = {};
    earliest_time = Inf;
    latest_time = -Inf;
    
    % 处理每条观测记录
    for i = 1:length(lines)
        line = strtrim(lines{i});
        if isempty(line), continue; end
        
        % 解析MPC80格式
        parts = strsplit(line);
        
        if length(parts) >= 13
            target_id = parts{1};
            
            % 提取年份（从"C2025"这样的字符串）
            obs_type_year = parts{2};
            year_str = obs_type_year(2:end);
            year = str2double(year_str);
            
            month = str2double(parts{3});
            day_frac = str2double(parts{4});
            
            % 赤经
            ra_h = str2double(parts{5});
            ra_m = str2double(parts{6});
            ra_s = str2double(parts{7});
            ra_deg = (ra_h + ra_m/60 + ra_s/3600) * 15;
            
            % 赤纬
            dec_str = parts{8};
            dec_d = abs(str2double(dec_str));
            dec_m = str2double(parts{9});
            dec_s = str2double(parts{10});
            dec_deg = (dec_d + dec_m/60 + dec_s/3600);
            if dec_str(1) == '-'
                dec_deg = -dec_deg;
            end
            
            % 星等
            mag = str2double(parts{11});
            
            % 波段
            band = parts{12};
            
            % 观测站代码
            station_code = parts{13};
            
            % 转换时间
            iso_time = mpc_time_to_iso(year, month, day_frac);
            
            % 转换时间戳为数值格式用于比较
            try
                time_num = posixtime(datetime(iso_time, 'InputFormat', 'yyyy-MM-dd''T''HH:mm:ss.SSSSSS'));
                
                % 更新时间范围
                earliest_time = min(earliest_time, time_num);
                latest_time = max(latest_time, time_num);
            catch
                % 如果时间解析失败，使用默认值
                if isinf(earliest_time)
                    earliest_time = posixtime(datetime(now, 'ConvertFrom', 'datenum'));
                    latest_time = earliest_time;
                end
            end
            
            % 保存观测数据
            obs.time = iso_time;
            obs.ra_deg = ra_deg;
            obs.dec_deg = dec_deg;
            obs.mag = mag;
            obs.band = band;
            obs.station = station_code;
            obs.target = target_id;
            
            observations{end+1} = obs;
        end
    end
    
    if isempty(observations)
        error('没有找到有效的观测数据');
    end
    
    % 按观测站分组
    stations = {};
    station_data = struct();
    
    for i = 1:length(observations)
        obs = observations{i};
        station = obs.station;
        
        if ~isfield(station_data, station)
            station_data.(station) = {};
            stations{end+1} = station;
        end
        
        station_data.(station){end+1} = obs;
    end
    
    % 创建TDM文件
    fid_tdm = fopen(output_file, 'w');
    
    % TDM头部（符合CCSDS 503.0-B-2标准）
    fprintf(fid_tdm, 'CCSDS_TDM_VERS = 2.0\r\n');
    fprintf(fid_tdm, 'CREATION_DATE = %s\r\n', datestr(now, 'yyyy-mm-ddTHH:MM:SS.FFF'));
    fprintf(fid_tdm, 'ORIGINATOR = MPC80_TO_TDM\r\n');
    fprintf(fid_tdm, 'COMMENT Generated from MPC80 optical observations\r\n');
    fprintf(fid_tdm, '\r\n');
    
    % 为每个观测站创建一个段（segment）
    for s = 1:length(stations)
        station = stations{s};
        obs_list = station_data.(station);
        
        % 计算该观测站的时间范围
        station_earliest = Inf;
        station_latest = -Inf;
        for i = 1:length(obs_list)
            obs = obs_list{i};
            time_num = posixtime(datetime(obs.time, 'InputFormat', 'yyyy-MM-dd''T''HH:mm:ss.SSSSSS'));
            station_earliest = min(station_earliest, time_num);
            station_latest = max(station_latest, time_num);
        end
        
        start_dt = datetime(station_earliest, 'ConvertFrom', 'posixtime', 'Format', 'yyyy-MM-dd''T''HH:mm:ss.SSSSSS');
        stop_dt = datetime(station_latest, 'ConvertFrom', 'posixtime', 'Format', 'yyyy-MM-dd''T''HH:mm:ss.SSSSSS');
        
        % META段开始
        fprintf(fid_tdm, 'META_START\r\n');
        
        % 元数据部分
        fprintf(fid_tdm, 'TIME_SYSTEM = UTC\r\n');
        fprintf(fid_tdm, 'START_TIME = %s\r\n', char(start_dt));
        fprintf(fid_tdm, 'STOP_TIME = %s\r\n', char(stop_dt));
        fprintf(fid_tdm, 'PARTICIPANT_1 = %s\r\n', station);
        fprintf(fid_tdm, 'PARTICIPANT_2 = %s\r\n', obs_list{1}.target);
        fprintf(fid_tdm, 'MODE = SEQUENTIAL\r\n');
        fprintf(fid_tdm, 'PATH = 2,1\r\n');  % 2->1表示从目标到观测站
        fprintf(fid_tdm, 'ANGLE_TYPE = RADEC\r\n');
        fprintf(fid_tdm, 'REFERENCE_FRAME = EMEJ2000\r\n');
        fprintf(fid_tdm, 'DATA_QUALITY = VALIDATED\r\n');
        fprintf(fid_tdm, 'META_STOP\r\n');
        fprintf(fid_tdm, '\r\n');
        
        % DATA段开始
        fprintf(fid_tdm, 'DATA_START\r\n');
        
        % 写入该观测站的所有数据
        for i = 1:length(obs_list)
            obs = obs_list{i};
            
            % 添加星等信息到注释
            fprintf(fid_tdm, 'COMMENT Mag=%.1f, Band=%s\r\n', obs.mag, obs.band);
            
            % 使用标准格式：keyword = timetag value
            % ANGLE_1对应赤经，ANGLE_2对应赤纬
            fprintf(fid_tdm, 'ANGLE_1 = %s %.8f\r\n', obs.time, obs.ra_deg);
            fprintf(fid_tdm, 'ANGLE_2 = %s %.8f\r\n', obs.time, obs.dec_deg);
        end
        
        fprintf(fid_tdm, 'DATA_STOP\r\n');
        fprintf(fid_tdm, '\r\n');
    end
    
    fclose(fid_tdm);
    
    fprintf('转换完成！\n');
    fprintf('生成文件: %s\n', output_file);
    fprintf('总观测数量: %d\n', length(observations));
    fprintf('观测站数量: %d\n', length(stations));
    fprintf('观测站列表: %s\n', strjoin(stations, ', '));
    
    % 显示文件结构示例
    fprintf('\n文件结构示例：\n');
    fprintf('-------------------------------\n');
    fprintf('CCSDS_TDM_VERS = 2.0\n');
    fprintf('CREATION_DATE = ...\n');
    fprintf('ORIGINATOR = MPC80_TO_TDM\n');
    fprintf('COMMENT Generated from MPC80 optical observations\n');
    fprintf('\n');
    fprintf('META_START\n');
    fprintf('TIME_SYSTEM = UTC\n');
    fprintf('PARTICIPANT_1 = K19\n');
    fprintf('PARTICIPANT_2 = 8D9R001\n');
    fprintf('MODE = SEQUENTIAL\n');
    fprintf('PATH = 2,1\n');
    fprintf('ANGLE_TYPE = RADEC\n');
    fprintf('REFERENCE_FRAME = EMEJ2000\n');
    fprintf('META_STOP\n');
    fprintf('\n');
    fprintf('DATA_START\n');
    fprintf('COMMENT Mag=19.3, Band=G\n');
    fprintf('ANGLE_1 = 2025-11-28T00:45:15.033600 137.66769167\n');
    fprintf('ANGLE_2 = 2025-11-28T00:45:15.033600 20.43746111\n');
    fprintf('DATA_STOP\n');
end

function iso_time = mpc_time_to_iso(year, month, day_fraction)
    % 将MPC时间转换为ISO 8601格式
    day = floor(day_fraction);
    fraction = day_fraction - day;
    
    total_seconds = fraction * 86400;
    hours = floor(total_seconds / 3600);
    minutes = floor(mod(total_seconds, 3600) / 60);
    seconds = mod(total_seconds, 60);
    
    % 格式化为ISO 8601，保留6位小数
    iso_time = sprintf('%04d-%02d-%02dT%02d:%02d:%09.6f', ...
                       year, month, day, hours, minutes, seconds);
end

% 主程序
mpc80_to_tdm('CE6_OBS_2025NovDec - 1.txt', 'ce6_tdm_fixed.tdm');