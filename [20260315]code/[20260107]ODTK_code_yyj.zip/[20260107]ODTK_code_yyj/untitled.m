clear ;clc;
%% 开启ODTK
% Make sure ODTK is running with the HTTP server started (default port is 9393)
winopen('MAIN_LaunchODTK-9494-od.cmd')

% -----------------------------------------------------------
%% 连接ODTK
% Add the ODTK API library in the search path
addpath('C:\Program Files\AGI\ODTK 7\CodeSamples\CrossPlatform\ODTK\matlab\lib');
client = Client('localhost', 9494);
odtk = client.Root;
odtkChildCount = odtk.children.count;


%% 创建场景
% ensure new scenario
if odtkChildCount > 0
    % close scenario
    odtk.application.deleteObject("", odtk.scenario{0});
    fprintf("Scenario closed.\n");
end
scenario = odtk.application.createObj(odtk, "Scenario", "TestScenario");
fprintf("Scenario created.\n");

scenario.EarthDefinition.EOPData.Filename = 'C:\ProgramData\AGI\ODTK 7\DynamicEarthData\EOP-All-v1.1.txt';

measurementFiles = scenario.Measurements.Files;
fprintf("Measurement files count: %i\n", measurementFiles.count);
% Clear the list
measurementFiles.clear();
% Add a new item to it
ne = measurementFiles.NewElem();
ne.Enabled = true;
ne.FileName = 'D:\keyan\projects\OD\code_yyj\ce6_tdm_fixed.tdm';
measurementFiles.push_back(ne);
fprintf("Measurement files count: %i\n", measurementFiles.count);
   


%% 创建卫星
% 定义卫星名称
satName = "yyj";

% 创建卫星并获取引用
mySat = odtk.application.createObj(odtk.scenario{0}, "Satellite", satName);


fprintf('创建卫星: %s\n', satName);

% 设置编号
ne = mySat.MeasurementProcessing.TrackingIDAliases.NewElem();
ne.AliasID = '8D9R001';
mySat.MeasurementProcessing.TrackingIDAliases.push_back(ne);


mySat.ForceModel.Gravity.DegreeAndOrder = 70; % 地球非球型
mySat.ForceModel.Gravity.Tides.SolidTides = 'false'; % 固体潮
mySat.ForceModel.Gravity.Tides.OceanTides = 'false'; % 海洋潮
mySat.ForceModel.Drag.Use = 'No'; % 大气
% satellite.ForceModel.Drag.Model.CD = 2.2;
% satellite.ForceModel.Drag.Model.Area.Set(20 , 'm^2');
mySat.ForceModel.SolarPressure.Use = 'No'; % 光压
% satellite.ForceModel.SolarPressure.Model.Cr = 1;
% satellite.ForceModel.SolarPressure.Model.Area.Set(20 , 'm^2');
mySat.ForceModel.Gravity.ThirdBodies.Settings{0}.GMSource = 'JPL DE'; % 三体引力（默认）
mySat.ForceModel.Gravity.ThirdBodies.Settings{1}.GMSource = 'JPL DE';


%% 建立地面测站
% D29
trakSys = odtk.application.createObj(odtk.scenario{0}, 'TrackingSystem', 'trakSys');
facility = odtk.application.createObj(trakSys, 'Facility', 'D29');
facility.MeasurementProcessing.TrackingID = 101;
ne = facility.MeasurementProcessing.TrackingIDAliases.NewElem();
ne.AliasID = 'D29';
facility.MeasurementProcessing.TrackingIDAliases.push_back(ne);
pos = facility.Position.ToGeodetic();
pos.Lat.Set(32.56, 'deg');
pos.Lon.Set(118.4639, 'deg');
pos.Alt.Set(100, 'm');
facility.Position.Assign(pos);
pos = facility.Position.ToGeodetic();
printGeodeticPos(pos);

% 测量值
RA_BiasSigma = 20;
RA_WhiteNoiseSigma = 10;
Dec_BiasSigma = 20;
Dec_WhiteNoiseSigma = 10;
facility.MeasurementStatistics.clear();
facility.MeasurementStatistics.InsertByName('Right Ascension');
facility.MeasurementStatistics.InsertByName('Declination');
RA = facility.MeasurementStatistics{0};
RA.Type.BiasSigma.Set(RA_BiasSigma, 'arcSec');
RA.Type.WhiteNoiseSigma.Set(RA_WhiteNoiseSigma, 'arcSec');
Dec = facility.MeasurementStatistics{1};
Dec.Type.BiasSigma.Set(Dec_BiasSigma, 'arcSec');
Dec.Type.WhiteNoiseSigma.Set(Dec_WhiteNoiseSigma, 'arcSec');

facility.OpticalProperties.ReferenceFrame = 'MEME J2000';
facility.AntennaType = 'Optical';



% G96
facility = odtk.application.createObj(trakSys, 'Facility', 'G96');
facility.MeasurementProcessing.TrackingID = 102;
ne = facility.MeasurementProcessing.TrackingIDAliases.NewElem();
ne.AliasID = 'G96';
facility.MeasurementProcessing.TrackingIDAliases.push_back(ne);
pos = facility.Position.ToGeodetic();
pos.Lat.Set(32.26, 'deg');
pos.Lon.Set(249.21128, 'deg');
pos.Alt.Set(2790, 'm');
facility.Position.Assign(pos);
pos = facility.Position.ToGeodetic();
printGeodeticPos(pos);

% 测量值
RA_BiasSigma = 20;
RA_WhiteNoiseSigma = 10;
Dec_BiasSigma = 20;
Dec_WhiteNoiseSigma = 10;
facility.MeasurementStatistics.clear();
facility.MeasurementStatistics.InsertByName('Right Ascension');
facility.MeasurementStatistics.InsertByName('Declination');
RA = facility.MeasurementStatistics{0};
RA.Type.BiasSigma.Set(RA_BiasSigma, 'arcSec');
RA.Type.WhiteNoiseSigma.Set(RA_WhiteNoiseSigma, 'arcSec');
Dec = facility.MeasurementStatistics{1};
Dec.Type.BiasSigma.Set(Dec_BiasSigma, 'arcSec');
Dec.Type.WhiteNoiseSigma.Set(Dec_WhiteNoiseSigma, 'arcSec');

facility.OpticalProperties.ReferenceFrame = 'MEME J2000';
facility.AntennaType = 'Optical';



% K19
facility = odtk.application.createObj(trakSys, 'Facility', 'K19');
facility.MeasurementProcessing.TrackingID = 103;
ne = facility.MeasurementProcessing.TrackingIDAliases.NewElem();
ne.AliasID = 'K19';
facility.MeasurementProcessing.TrackingIDAliases.push_back(ne);
pos = facility.Position.ToGeodetic();
pos.Lat.Set(43.8, 'deg');
pos.Lon.Set(5.64731, 'deg');
pos.Alt.Set(1000, 'm');
facility.Position.Assign(pos);
pos = facility.Position.ToGeodetic();
printGeodeticPos(pos);

% 测量值
RA_BiasSigma = 20;
RA_WhiteNoiseSigma = 10;
Dec_BiasSigma = 20;
Dec_WhiteNoiseSigma = 10;
facility.MeasurementStatistics.clear();
facility.MeasurementStatistics.InsertByName('Right Ascension');
facility.MeasurementStatistics.InsertByName('Declination');
RA = facility.MeasurementStatistics{0};
RA.Type.BiasSigma.Set(RA_BiasSigma, 'arcSec');
RA.Type.WhiteNoiseSigma.Set(RA_WhiteNoiseSigma, 'arcSec');
Dec = facility.MeasurementStatistics{1};
Dec.Type.BiasSigma.Set(Dec_BiasSigma, 'arcSec');
Dec.Type.WhiteNoiseSigma.Set(Dec_WhiteNoiseSigma, 'arcSec');

facility.OpticalProperties.ReferenceFrame = 'MEME J2000';
facility.AntennaType = 'Optical';




% N56
facility = odtk.application.createObj(trakSys, 'Facility', 'N56');
facility.MeasurementProcessing.TrackingID = 104;
ne = facility.MeasurementProcessing.TrackingIDAliases.NewElem();
ne.AliasID = 'N56';
facility.MeasurementProcessing.TrackingIDAliases.push_back(ne);
pos = facility.Position.ToGeodetic();
pos.Lat.Set(32.18, 'deg');
pos.Lon.Set(80.02675, 'deg');
pos.Alt.Set(5000, 'm');
facility.Position.Assign(pos);
pos = facility.Position.ToGeodetic();
printGeodeticPos(pos);

% 测量值
RA_BiasSigma = 20;
RA_WhiteNoiseSigma = 10;
Dec_BiasSigma = 20;
Dec_WhiteNoiseSigma = 10;
facility.MeasurementStatistics.clear();
facility.MeasurementStatistics.InsertByName('Right Ascension');
facility.MeasurementStatistics.InsertByName('Declination');
RA = facility.MeasurementStatistics{0};
RA.Type.BiasSigma.Set(RA_BiasSigma, 'arcSec');
RA.Type.WhiteNoiseSigma.Set(RA_WhiteNoiseSigma, 'arcSec');
Dec = facility.MeasurementStatistics{1};
Dec.Type.BiasSigma.Set(Dec_BiasSigma, 'arcSec');
Dec.Type.WhiteNoiseSigma.Set(Dec_WhiteNoiseSigma, 'arcSec');

facility.OpticalProperties.ReferenceFrame = 'MEME J2000';
facility.AntennaType = 'Optical';




% P13
facility = odtk.application.createObj(trakSys, 'Facility', 'P13');
facility.MeasurementProcessing.TrackingID = 105;
ne = facility.MeasurementProcessing.TrackingIDAliases.NewElem();
ne.AliasID = 'P13';
facility.MeasurementProcessing.TrackingIDAliases.push_back(ne);
pos = facility.Position.ToGeodetic();
pos.Lat.Set(39.64, 'deg');
pos.Lon.Set(115.57333, 'deg');
pos.Alt.Set(1990, 'm');
facility.Position.Assign(pos);
pos = facility.Position.ToGeodetic();
printGeodeticPos(pos);

% 测量值
RA_BiasSigma = 20;
RA_WhiteNoiseSigma = 10;
Dec_BiasSigma = 20;
Dec_WhiteNoiseSigma = 10;
facility.MeasurementStatistics.clear();
facility.MeasurementStatistics.InsertByName('Right Ascension');
facility.MeasurementStatistics.InsertByName('Declination');
RA = facility.MeasurementStatistics{0};
RA.Type.BiasSigma.Set(RA_BiasSigma, 'arcSec');
RA.Type.WhiteNoiseSigma.Set(RA_WhiteNoiseSigma, 'arcSec');
Dec = facility.MeasurementStatistics{1};
Dec.Type.BiasSigma.Set(Dec_BiasSigma, 'arcSec');
Dec.Type.WhiteNoiseSigma.Set(Dec_WhiteNoiseSigma, 'arcSec');

facility.OpticalProperties.ReferenceFrame = 'MEME J2000';
facility.AntennaType = 'Optical';





% U62
facility = odtk.application.createObj(trakSys, 'Facility', 'U62');
facility.MeasurementProcessing.TrackingID = 106;
ne = facility.MeasurementProcessing.TrackingIDAliases.NewElem();
ne.AliasID = 'U62';
facility.MeasurementProcessing.TrackingIDAliases.push_back(ne);
pos = facility.Position.ToGeodetic();
pos.Lat.Set(35.66, 'deg');
pos.Lon.Set(238.95508, 'deg');
pos.Alt.Set(1000, 'm');
facility.Position.Assign(pos);
pos = facility.Position.ToGeodetic();
printGeodeticPos(pos);

% 测量值
RA_BiasSigma = 20;
RA_WhiteNoiseSigma = 10;
Dec_BiasSigma = 20;
Dec_WhiteNoiseSigma = 10;
facility.MeasurementStatistics.clear();
facility.MeasurementStatistics.InsertByName('Right Ascension');
facility.MeasurementStatistics.InsertByName('Declination');
RA = facility.MeasurementStatistics{0};
RA.Type.BiasSigma.Set(RA_BiasSigma, 'arcSec');
RA.Type.WhiteNoiseSigma.Set(RA_WhiteNoiseSigma, 'arcSec');
Dec = facility.MeasurementStatistics{1};
Dec.Type.BiasSigma.Set(Dec_BiasSigma, 'arcSec');
Dec.Type.WhiteNoiseSigma.Set(Dec_WhiteNoiseSigma, 'arcSec');

facility.OpticalProperties.ReferenceFrame = 'MEME J2000';
facility.AntennaType = 'Optical';




%% 创建IOD
% 添加IOD
IOD_Ground = odtk.application.createObj(odtk.scenario{0}.yyj, 'InitialOrbitDetermination', 'IOD_Ground');
fprintf('InitialOrbitDetermination "IOD_Ground" created.\n');


% 测量方法
IOD_Ground.Method.Type = 'GoodingAnglesOnly';

% 设置测站
IOD_Ground.Method.TrackerList.clear();
IOD_Ground.Method.TrackerList.Insert('trakSys.D29');
IOD_Ground.Method.TrackerList.Insert('trakSys.G96');
IOD_Ground.Method.TrackerList.Insert('trakSys.K19');
IOD_Ground.Method.TrackerList.Insert('trakSys.N56');
IOD_Ground.Method.TrackerList.Insert('trakSys.P13');
IOD_Ground.Method.TrackerList.Insert('trakSys.U62');

% IOD添加三次观测数据

IOD_Ground.Method.SelectedMeasurements.Insert('000000  28 Nov 2025 00:45:15.034          K19 RaDec     137.7   20.4')

IOD_Ground.Method.SelectedMeasurements.Insert('155945  29 Nov 2025 20:04:20.294          D29 RaDec     140.3   19.5')
IOD_Ground.Method.SelectedMeasurements.Insert('242267  30 Nov 2025 20:03:01.757          P13 RaDec     141.9   18.8');

selected_count = IOD_Ground.Method.SelectedMeasurements.Count;
fprintf('已选择 %d 个测量数据\n', selected_count);
        
      
IOD_Ground.go();
IOD_Ground.transfer();





%% 创建最小二乘
% 添加LS
LS_Ground = odtk.application.createObj(odtk.scenario{0}.yyj, 'LeastSquares', 'LS_Ground');
fprintf('LeastSquares "LS_Ground" created.\n');

% 设置测站
LS_Ground.TrackerList.clear();
LS_Ground.TrackerList.Insert('trakSys.D29');
LS_Ground.TrackerList.Insert('trakSys.G96');
LS_Ground.TrackerList.Insert('trakSys.K19');
LS_Ground.TrackerList.Insert('trakSys.N56');
LS_Ground.TrackerList.Insert('trakSys.P13');
LS_Ground.TrackerList.Insert('trakSys.U62');

% 测量类型
LS_Ground.MeasTypes.clear();
LS_Ground.MeasTypes.Insert('Right Ascension');
LS_Ground.MeasTypes.Insert('Declination');

% LS添加一行
ls_newElem = LS_Ground.LeastSquares.Stages.NewElem();
LS_Ground.LeastSquares.Stages.push_back(ls_newElem);

% 提取
ls_temp = LS_Ground.LeastSquares.Stages{0};

% 修改迭代次数
ls_temp.MaxIterations = 20;
ls_temp.StartTime.Set('29 Nov 2025 20:04:20.294' , 'UTCG');
ls_temp.StopTime.Set('30 Dec 2025 00:04:20.294' , 'UTCG');





LS_Ground.go();
LS_Ground.transfer();









%% 创建滤波器
Filter_Ground = odtk.application.createObj(odtk.scenario{0}, 'Filter', 'Filter1');
fprintf('Filter "Filter_Ground" created.\n');

% 指定卫星
Filter_Ground.SatelliteList.clear();
Filter_Ground.SatelliteList.InsertByName('yyj');

% 设置测站
Filter_Ground.TrackerList.clear();
Filter_Ground.TrackerList.Insert('trakSys.D29');
Filter_Ground.TrackerList.Insert('trakSys.G96');
Filter_Ground.TrackerList.Insert('trakSys.K19');
Filter_Ground.TrackerList.Insert('trakSys.N56');
Filter_Ground.TrackerList.Insert('trakSys.P13');
Filter_Ground.TrackerList.Insert('trakSys.U62');

% 测量类型
Filter_Ground.MeasTypes.clear();
Filter_Ground.MeasTypes.Insert('Right Ascension');
Filter_Ground.MeasTypes.Insert('Declination');

% 不输出平滑器数据
Filter_Ground.Output.SmootherData.Generate = 1;

% 修改输出文件名
prop_name = 'TestScenario';
Filter_Ground.Output.DataArchive.Filename = ['D:\keyan\projects\OD\code_yyj\ODTK\' , prop_name , '.filrun'];
Filter_Ground.Output.SmootherData.Generate = 1;


Filter_Ground.go();




%%
% 清空Products
odtk.ProductBuilder.DataProducts.clear();

% 产品名称
product_name = 'Classical_Elements';

% 新建
newElem = odtk.ProductBuilder.DataProducts.NewElem();
odtk.ProductBuilder.DataProducts.push_back(newElem);
product = odtk.ProductBuilder.DataProducts{odtk.ProductBuilder.DataProducts.count - 1};
% 修改名字
product.Name.Assign(product_name);
% 输入
newSrc = product.Inputs.DataSources.NewElem();
product.Inputs.DataSources.push_back(newSrc);
product.Inputs.DataSources{0}.Filename = ['D:\keyan\projects\OD\code_yyj\ODTK\' , prop_name , '.filrun'];
% 输出
product.Outputs.Style = 'C:\Program Files\AGI\ODTK 7\ODTK\AppData\Styles\Static\Classical Elements.pyrpt';
product.Outputs.Display = 1;
product.Outputs.Export.Enabled = 0;

% 运行Static Product Builder
odtk.ProductBuilder.GenerateProduct(product_name);

%% 保存文件
% 定义自定义的保存文件夹
projectFolder = 'D:\keyan\projects\OD\code_yyj\ODTK';
scenarioFileName = 'OD.sco';

% 确保文件夹存在，如果不存在则创建
if ~exist(projectFolder, 'dir')
    mkdir(projectFolder);
    fprintf('创建文件夹: %s\n', projectFolder);
end

% 构建完整文件路径
scenarioFilePath = fullfile(projectFolder, scenarioFileName);

% 保存场景
odtk.SaveObj(odtk.scenario{0}, scenarioFilePath, true);
fprintf("场景已保存到: %s\n", scenarioFilePath);





%% functions

function printKeplerianOrbitState(os)
    fprintf("Epoch : %s UTCG, Eccentricity: %f, " + ...
            "TrueArgOfLatitude: %f deg, Inclination: %f deg, " + ...
            "RAAN: %f deg, ArgOfPerigee: %f deg rad\n", ...
            os.Epoch.Format("UTCG"), ...
            os.Eccentricity, ...
            os.TrueArgOfLatitude.GetIn("deg"), ...
            os.Inclination.GetIn("deg"), ...
            os.RAAN.GetIn("deg"), ...
            os.ArgOfPerigee.GetIn("rad"));
end

function printGeodeticPos(p)
    fprintf("Lat : %f deg, Lon: %f deg, Alt: %f m\n", ...
        p.Lat.GetIn("deg"), ...
        p.Lon.GetIn("deg"), ...
        p.Alt.GetIn("m"));
end