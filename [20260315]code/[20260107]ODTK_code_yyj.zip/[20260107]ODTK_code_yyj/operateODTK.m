% ODTK（Orbit Determination Tool Kit）是基于 AGI/STK 开发的卫星轨道确定工具包，
% 能为卫星控制提供定轨服务，包括轨道参数确定、星历预测以及偏差校准等。ODTK系统可
% 进行轨道参数分析、最优化，并对碰撞概率进行计算。
% ODTK操作部分--------
% 输入：
%    strFilename,strSatID,strTrackID
%    文件名，卫星ID，测站ID
% 数据整理部分参见帮助文件Measurement Formats in ODTK
% 使用GEOSC文件较为靠谱
% by 戴正旭 20200901
% 推荐参考文献：
%    黄晓斌, 张燕, 卢明,等. 基于ODTK的卫星初始轨道确定[J]. 空军预警学院学报, 2012, 26(2):108-110.
%    鄢青青, 沈怀荣, 邵琼玲. 基于MATLAB与ODTK的卫星轨道确定精度仿真分析方法[J]. 航天控制, 2015(02):84-88.
%    htm调试：C:\Program Files (x86)\AGI\ODTK 6\ODTK\AppData\LauchPad\Utilities\ScriptingTool.htm

function operateODTK(strFilename,strSatID,strTrackID)
clear all;clc;
try
    % 获取运行中的ODTK句柄
    app = actxGetRunningServer('ODTK.Application');
    odtk = app.get('Personality');
    checkempty = odtk.invoke('Children').invoke('Count');
    disp(checkempty)
    
    if checkempty == 0
        % 未发现打开场景，新建一个
        app.visible = 1;
    else
        % 如有打开尝尽，询问是否关闭
        rtn = questdlg({'Close th current scenario?',' ','WARNING: If you have no saved your progress will be lost.'});
        if ~strcmp(rtn,'Yes')
            return
        else
            app.usercontrol = false;
            odtk.release;
        end
    end
    
catch
    % ODTK未运行，创建实例，并获取句柄
    
    app = actxserver('ODTK.Application');
    odtk = app.get('Personality');
    app.visible = true;
    app.usercontrol = true;
end

% 新建场景、卫星、观测、测站、初轨确定
scen   = odtk.invoke('CreateObj', odtk,   'Scenario',       'MyScenario'); 
sat    = odtk.invoke('CreateObj', scen,   'Satellite',      'MySat');
trkSys = odtk.invoke('CreateObj', scen,   'TrackingSystem', 'TrkSys');
trkFac = odtk.invoke('CreateObj', trkSys, 'Facility',       'Fac');
iniODT = odtk.invoke('CreateObj', sat, 'InitialOrbitDetermination');

% 添加观测资料
mfiles = odtk.invoke('Scenario').invoke('Item',0).invoke('Measerements').invoke('Files');
mfiles.invoke('clear');
ne = mfiles.invoke('NewElem');
ne.set('Enabled', true);
ne.set('Filename',strFilename);
mfiles.invoke('push_back', ne);

% 设置场景时间为观测资料首点
scen.invoke('DefaultTimes').invoke('Processes').set('StartMode', 'EarliestSatEpoch');

% 设置测站工位
pos = scen.invoke('TrackingSystem').invoke('Item', 0).invoke('Facility').invoke('Item', 0).invoke('Position').invoke('ToGeodetic');
 
pos.invoke('Lat').invoke('Set', 10, 'deg');
pos.invoke('Lon').invoke('Set', 20, 'deg');
pos.invoke('Alt').invoke('Set', 100, 'm');
 
scen.invoke('TrackingSystem').invoke('Item', 0).invoke('Facility').invoke('Item', 0).invoke('Position').invoke('Assign', pos);

% 设置测站ID
trkFac.invoke('MeasurementProcessing').set('TrackingID',strTrackID);
% 设置卫星ID
sat.invoke('MeasurementProcessing').set('TrackingID', strSatID);

% 设置初轨确定方法
iniODT.invoke('Method').set('SelectedFacility', iniODT.invoke('Method').invoke(SelectedFacility).invoke('Choices').invoke('Item',0));

% 添加定轨资料
nMeasNum = iniODT.invoke('SelectedMeasurements').invoke('Choices').invoke('Count');
hNum = 2;
mNum = nMeasNum/2;
eNum = nMeasNum-1;
mDataPoints = iniODT.invoke('Method').set('SelectedFacility');
%清除列表
mDataPoints.invoke('clear');
% 添加三个数据
Nepal= iniODT.invoke('SelectedMeasurements').invoke('Choices').invoke('Item',hNum);
mDataPoints.invoke('insert',nep);
Nepal= iniODT.invoke('SelectedMeasurements').invoke('Choices').invoke('Item',mNum);
mDataPoints.invoke('insert',nep);
Nepal= iniODT.invoke('SelectedMeasurements').invoke('Choices').invoke('Item',eNum);
mDataPoints.invoke('insert',nep);

% 开始定轨，并将结果转换为开普勒根数，默认ICRS坐标系
iniODT.invoke('Go');
iniODT.invoke('Output'),invoke('OrbitState').set('DisplayCoorFlag','Keplerian');
% 得到结果
strTime = iniODT.invoke('Output').invoke('OrbitState').invoke('Epoch').invoke('Format','UTCG').invoke('value');
dR = iniODT.invoke('Output').invoke('OrbitState').invoke('ToKeplerian').invoke('SemiMajorAxis').invoke('value');
dE = iniODT.invoke('Output').invoke('OrbitState').invoke('ToKeplerian').invoke('Eccentricity').invoke('value');
df = iniODT.invoke('Output').invoke('OrbitState').invoke('ToKeplerian').invoke('TrueArgofLatitude').invoke('value');
dI = iniODT.invoke('Output').invoke('OrbitState').invoke('ToKeplerian').invoke('Inclination').invoke('value');
dO = iniODT.invoke('Output').invoke('OrbitState').invoke('ToKeplerian').invoke('RAAN').invoke('value');
dOandf = iniODT.invoke('Output').invoke('OrbitState').invoke('ToKeplerian').invoke('ArgofPerigee').invoke('value');

fprintf('       Time(UTC)        R(km)       E(deg)      I(deg)      O(deg)    f(deg)    O+f(deg)\n');
fprintf('%s %.5f %.5f %.5f %.5f %.5f %.5f  \n',strTime,dR,dE,df,dI,dO,dOandf);

% 退出ODTK
odtk.release;
app.release;
clear odtk;
clear app;

end